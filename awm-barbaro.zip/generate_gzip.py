import gzip
import os

input_dir = 'data'
output_file = 'src/AWM_html_gz.h'

files = ['index.html', 'success.html', 'error.html']

print(f"Generating {output_file} from files in {input_dir}...")

with open(output_file, 'w', encoding='utf-8') as out:
    out.write('#ifndef AWM_HTML_GZ_H\n')
    out.write('#define AWM_HTML_GZ_H\n\n')
    out.write('#include <Arduino.h>\n\n')

    for fname in files:
        path = os.path.join(input_dir, fname)
        if not os.path.exists(path):
            print(f"Warning: {fname} not found in {input_dir}")
            continue
        
        with open(path, 'rb') as f:
            content = f.read()
            # Compress using gzip
            compressed = gzip.compress(content)
            
        var_name = fname.replace('.', '_').upper() + "_GZ"
        len_name = fname.replace('.', '_').upper() + "_GZ_LEN"
        
        print(f"Processing {fname}: {len(content)} bytes -> {len(compressed)} bytes ({(len(compressed)/len(content))*100:.1f}%)")

        out.write(f'// {fname} ({len(content)} bytes -> {len(compressed)} bytes)\n')
        out.write(f'const uint32_t {len_name} = {len(compressed)};\n')
        # pgmspace.h is included via Arduino.h usually, PROGMEM is valid on ESP8266/ESP32
        out.write(f'const uint8_t {var_name}[] PROGMEM = {{\n')
        
        for i, byte in enumerate(compressed):
            out.write(f'0x{byte:02X},')
            if (i + 1) % 16 == 0:
                out.write('\n')
        
        out.write('\n};\n\n')

    out.write('#endif\n')

print("Done!")
